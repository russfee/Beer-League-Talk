<?php // Sidekick Module ?>
<div class="row constrain">
<img src="<?php the_sub_field('banner_image'); ?>">
</div><!--row-->