<?php // Paragraph Module ?>

<div class="row constrain">
	<img src="<?php the_sub_field('image'); ?>">
</div> <!--row-->
