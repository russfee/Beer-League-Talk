<?php // Ways to listen ?>
<!--==========HOW TO LISTEN START*============-->
<div class="row" style="padding: 40px 0">
	<div class="stylized-header-container" style=" text-align: left; padding-bottom: 40px;">	
		<h4 style="font-size: 18px; color: #333;"></h4>
		<h2 style="font-size: 30px; color: #333;">How to listen</h2>
		<div style="background-color:#d9ee12;text-align: left;" class="stylized-title-underline"></div>
	</div> <!--stylized-header-container-->
	<div class="listen-container">
		<div class="listen-item-1">
			<img src="http://beerleaguedev.local/wp-content/uploads/2018/05/Apple-logo.png">
		</div> <!--listen-item-1-->
		<div class="listen-item-2">
			<img src="http://beerleaguedev.local/wp-content/uploads/2018/05/android_white.png">
		</div> <!--listen-item-2-->
		<div class="listen-item-3">
			<img src="http://beerleaguedev.local/wp-content/uploads/2018/05/desk-white.png">
		</div> <!--listen-item-3-->
	</div> <!--listen-container-->
	
</div> <!--row-->
<!--==========HOW TO LISTEN END*============-->
