<?php // MODULE - INSTAGRAM ?>
<!--==========INSTAGRAM START*============-->
<div class="row" style="padding: 40px 0">
	<div class="stylized-header-container" style=" text-align: left; padding-bottom: 40px;">	
		<h4 style="font-size: 18px; color: #333;"></h4>
		<h2 style="font-size: 30px; color: #333;">Instagram</h2>
		<div style="background-color:#d9ee12;text-align: left;" class="stylized-title-underline"></div>
	</div> <!--stylized-header-container-->
		<?php echo do_shortcode("[instagram-feed]"); ?>
	</div> <!--row-->
<!--==========INSTAGRAM END*============-->
