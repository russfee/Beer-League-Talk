<?php // Featured Shows ?>
<!--==========HOW TO LISTEN START*============-->
<div class="row" style="padding: 40px 0">
	<div class="stylized-header-container" style=" text-align: left; padding-bottom: 40px;">	
		<h4 style="font-size: 18px; color: #333;"></h4>
		<h2 style="font-size: 30px; color: #333;">Featured Shows</h2>
		<div style="background-color:#d9ee12;text-align: left;" class="stylized-title-underline"></div>
	</div> <!--stylized-header-container-->
	<div class="featured-container">
		<div class="featured-item-1">
			<img src="http://beerleaguedev.local/wp-content/uploads/2018/05/BLT-Logo.png">
		</div> <!--featured-item-1-->
		<div class="featured-item-2">
			<img src="http://beerleaguedev.local/wp-content/uploads/2018/05/GoalieShowLogo.png">
		</div> <!--featured-item-2-->
		<div class="featured-item-3">
			<img src="http://beerleaguedev.local/wp-content/uploads/2018/05/hatrickswayze.png">
		</div> <!--featured-item-3-->
	</div> <!--featured-container-->
	
</div> <!--row-->
<!--==========HOW TO LISTEN END*============-->
